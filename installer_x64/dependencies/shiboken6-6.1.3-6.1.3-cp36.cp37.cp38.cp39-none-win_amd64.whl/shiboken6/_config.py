shiboken_library_soversion = str(6.1)

version = "6.1.3"
version_info = (6, 1, 3, "", "")

__build_date__ = '2021-09-01T09:42:53+00:00'




__setup_py_package_version__ = '6.1.3'
